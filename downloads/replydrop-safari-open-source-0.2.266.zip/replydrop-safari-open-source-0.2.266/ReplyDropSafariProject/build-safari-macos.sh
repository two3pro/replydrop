#!/bin/zsh

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_PATH="$ROOT_DIR/ReplyDropSafari/ReplyDropSafari.xcodeproj"
SCHEME="ReplyDropSafari (macOS)"

DEFAULT_DEVELOPER_DIR="/Applications/Xcode.app/Contents/Developer"
SELECTED_DEVELOPER_DIR="$(xcode-select -p 2>/dev/null || true)"

if [[ -n "${DEVELOPER_DIR:-}" ]]; then
  RESOLVED_DEVELOPER_DIR="$DEVELOPER_DIR"
elif [[ -n "$SELECTED_DEVELOPER_DIR" && -x "$SELECTED_DEVELOPER_DIR/usr/bin/xcodebuild" ]]; then
  RESOLVED_DEVELOPER_DIR="$SELECTED_DEVELOPER_DIR"
else
  RESOLVED_DEVELOPER_DIR="$DEFAULT_DEVELOPER_DIR"
fi

XCODEBUILD_BIN="$RESOLVED_DEVELOPER_DIR/usr/bin/xcodebuild"
LSREGISTER_BIN="/System/Library/Frameworks/CoreServices.framework/Versions/Current/Frameworks/LaunchServices.framework/Versions/Current/Support/lsregister"

CONFIGURATION="${CONFIGURATION:-Release}"
DEVELOPMENT_TEAM="${DEVELOPMENT_TEAM:-}"
SIGNING_IDENTITY="${SIGNING_IDENTITY:-Apple Development}"
DERIVED_DATA_PATH="${DERIVED_DATA_PATH:-$ROOT_DIR/.DerivedData-release}"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/dist}"
INSTALL_TO_APPLICATIONS="${INSTALL_TO_APPLICATIONS:-0}"
VERIFY_SINGLE_PLUGIN_REGISTRATION="${VERIFY_SINGLE_PLUGIN_REGISTRATION:-1}"

PLUGIN_IDENTIFIER="com.replydrop.safari.Extension"
PLUGIN_NAME="ReplyDropSafari Extension.appex"

run_quiet() {
  "$@" >/dev/null 2>&1 || true
}

cleanup_derived_registration() {
  local derived_app_path="$1"
  local derived_plugin_path="$derived_app_path/Contents/PlugIns/$PLUGIN_NAME"

  if [[ -e "$derived_plugin_path" ]]; then
    echo "Removing derived plug-in registration"
    run_quiet pluginkit -r "$derived_plugin_path"
  fi

  if [[ -d "$derived_app_path" ]]; then
    echo "Unregistering derived app bundle"
    run_quiet "$LSREGISTER_BIN" -u "$derived_app_path"
    echo "Removing derived app bundle"
    rm -rf "$derived_app_path"
  fi
}

verify_single_plugin_registration() {
  local identifier="$1"
  local expected_plugin_path="$2"
  local report paths path_count expected_count

  report="$(pluginkit -m -A -D -vvv -i "$identifier" || true)"
  printf '%s\n' "$report"

  paths="$(printf '%s\n' "$report" | sed -n 's/^[[:space:]]*Path = //p')"
  path_count="$(printf '%s\n' "$paths" | sed '/^$/d' | wc -l | tr -d ' ')"
  expected_count="$(printf '%s\n' "$paths" | grep -Fxc "$expected_plugin_path" || true)"

  if [[ "$path_count" != "1" || "$expected_count" != "1" ]]; then
    echo "Expected exactly one registered Safari extension at:" >&2
    echo "  $expected_plugin_path" >&2
    return 1
  fi
}

if [[ ! -x "$XCODEBUILD_BIN" ]]; then
  echo "Xcode not found at: $XCODEBUILD_BIN" >&2
  echo "Set DEVELOPER_DIR or run: sudo xcode-select -s /Applications/Xcode.app/Contents/Developer" >&2
  exit 1
fi

if [[ ! -x "$LSREGISTER_BIN" ]]; then
  echo "lsregister not found at: $LSREGISTER_BIN" >&2
  exit 1
fi

if [[ -z "$DEVELOPMENT_TEAM" ]]; then
  cat >&2 <<'EOF'
Missing DEVELOPMENT_TEAM.

Example:
  DEVELOPMENT_TEAM=ABCDE12345 ./build-safari-macos.sh

Notes:
  - Use Apple Development for a local install on this Mac.
  - Use Developer ID Application for a distributable build.
  - A distributable build still needs notarization before sharing outside your machine.
EOF
  exit 1
fi

mkdir -p "$OUTPUT_DIR"

echo "Building $SCHEME"
echo "  Configuration: $CONFIGURATION"
echo "  Team: $DEVELOPMENT_TEAM"
echo "  Signing Identity: $SIGNING_IDENTITY"
echo "  Developer Dir: $RESOLVED_DEVELOPER_DIR"
echo "  Derived Data: $DERIVED_DATA_PATH"

"$XCODEBUILD_BIN" \
  -project "$PROJECT_PATH" \
  -scheme "$SCHEME" \
  -configuration "$CONFIGURATION" \
  -derivedDataPath "$DERIVED_DATA_PATH" \
  DEVELOPMENT_TEAM="$DEVELOPMENT_TEAM" \
  CODE_SIGN_STYLE=Automatic \
  CODE_SIGN_IDENTITY="$SIGNING_IDENTITY" \
  build \
  -allowProvisioningUpdates

APP_PATH="$DERIVED_DATA_PATH/Build/Products/$CONFIGURATION/ReplyDropSafari.app"
STAGED_APP_PATH="$OUTPUT_DIR/ReplyDropSafari.app"

if [[ ! -d "$APP_PATH" ]]; then
  echo "Build succeeded but app not found at: $APP_PATH" >&2
  exit 1
fi

APP_VERSION="$(defaults read "$APP_PATH/Contents/Info" CFBundleShortVersionString)"
ZIP_PATH="$OUTPUT_DIR/ReplyDropSafari-macOS-$APP_VERSION.zip"

rm -rf "$STAGED_APP_PATH" "$ZIP_PATH"
ditto "$APP_PATH" "$STAGED_APP_PATH"
ditto -c -k --keepParent "$STAGED_APP_PATH" "$ZIP_PATH"

echo
echo "Artifacts:"
echo "  App: $STAGED_APP_PATH"
echo "  Zip: $ZIP_PATH"

if [[ "$INSTALL_TO_APPLICATIONS" == "1" ]]; then
  INSTALL_PATH="/Applications/ReplyDropSafari.app"
  INSTALL_PLUGIN_PATH="$INSTALL_PATH/Contents/PlugIns/$PLUGIN_NAME"
  echo
  echo "Installing to $INSTALL_PATH"
  rm -rf "$INSTALL_PATH"
  ditto "$STAGED_APP_PATH" "$INSTALL_PATH"
  "$LSREGISTER_BIN" -f -R -trusted "$INSTALL_PATH" >/dev/null
  pluginkit -a "$INSTALL_PLUGIN_PATH"
  cleanup_derived_registration "$APP_PATH"
  if [[ "$VERIFY_SINGLE_PLUGIN_REGISTRATION" == "1" ]]; then
    echo
    echo "Verifying plug-in registration"
    verify_single_plugin_registration "$PLUGIN_IDENTIFIER" "$INSTALL_PLUGIN_PATH"
  fi
  echo "Installed: $INSTALL_PATH"
fi
