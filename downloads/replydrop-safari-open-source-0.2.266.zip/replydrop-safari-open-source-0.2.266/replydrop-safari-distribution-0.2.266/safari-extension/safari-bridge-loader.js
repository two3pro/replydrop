(function loadReplyDropApiBridgeForSafari(global) {
  const MARKER_ID = "replydrop-safari-bridge-status";

  function setMarker(stage, extra = {}) {
    try {
      const root = global.document?.documentElement;
      if (!root) {
        return;
      }
      let marker = global.document.getElementById(MARKER_ID);
      if (!(marker instanceof global.HTMLElement)) {
        marker = global.document.createElement("meta");
        marker.id = MARKER_ID;
        root.appendChild(marker);
      }
      marker.setAttribute("data-stage", String(stage || ""));
      Object.entries(extra).forEach(([key, value]) => {
        marker.setAttribute(`data-${key}`, String(value ?? ""));
      });
    } catch (_error) {}
  }

  function injectBridge() {
    try {
      const runtime = global.chrome?.runtime || global.browser?.runtime;
      if (!runtime?.getURL || !global.document?.documentElement) {
        setMarker("runtime-missing");
        return;
      }

      if (global.document.querySelector("script[data-replydrop-safari-bridge='external']")) {
        setMarker("script-already-present");
        return;
      }

      const script = global.document.createElement("script");
      script.src = runtime.getURL("replydrop-api-bridge.js");
      script.async = false;
      script.dataset.replydropSafariBridge = "external";
      script.addEventListener("load", () => {
        setMarker("script-loaded", {
          api: global.wrappedJSObject?.ReplyDropAPI ? "1" : "0",
          executor: global.wrappedJSObject?.ReplyDropExecutor ? "1" : "0"
        });
      });
      script.addEventListener("error", () => {
        setMarker("script-error");
      });
      (global.document.head || global.document.documentElement).appendChild(script);
      setMarker("script-appended", { src: script.src });
    } catch (error) {
      setMarker("inject-failed", { message: String(error?.message || error || "") });
      console.warn("[ReplyDrop] Safari API bridge injection failed", error);
    }
  }

  injectBridge();
  global.addEventListener("DOMContentLoaded", injectBridge, { once: true });
  global.addEventListener("load", injectBridge, { once: true });
  global.setTimeout(injectBridge, 800);
})(typeof globalThis !== "undefined" ? globalThis : window);
