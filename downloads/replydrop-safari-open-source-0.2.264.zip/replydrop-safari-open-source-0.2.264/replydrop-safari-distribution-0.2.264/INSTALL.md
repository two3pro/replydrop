# ReplyDrop Safari for macOS 0.2.264

这份公开包只保留 macOS / Safari 版本所需文件，以及辅助安装说明。
不单独提供仓库首页 README。
当前定位是源码公开 + 本地自签名安装，不提供官方签名安装包。

不提供：

- 批量自动回复工具
- 独立压测脚本 / CLI runner
- 已签名的可执行发布包

公开包里仍然保留页内快速面板，方便人工浏览候选与手动打开回复入口；
它不是独立 runner，也不会替代人工发送。

## 目录说明

- `safari-extension/`
  - Safari Web Extension 源码
- `../../ReplyDropSafariProject/`
  - 已整理好的 Xcode 工程与本地构建脚本

## 安装方式 A：直接用随包工程

前提：

- 已安装 Xcode
- 你自己的 Apple ID / Team 可用于本机签名

1. 用 Xcode 打开：
   - `../../ReplyDropSafariProject/ReplyDropSafari/ReplyDropSafari.xcodeproj`
2. 在 Xcode 中选择你自己的 Apple ID / Team。
3. 运行 macOS target，或在仓库根目录执行：
   ```bash
   DEVELOPMENT_TEAM=YOUR_TEAM_ID \
   INSTALL_TO_APPLICATIONS=1 \
   ./ReplyDropSafariProject/build-safari-macos.sh
   ```
4. 打开 Safari：
   - `设置 -> 扩展`
   - 启用 `ReplyDropSafari`
   - 允许访问 `x.com`

说明：
- 这条安装路径适合开发者和愿意自己签名的用户
- 如果你没有自己的 Apple ID / Team，就不能直接把这份源码包装成本机可安装扩展
- 如果你的 Xcode 不在默认位置，可以先设置 `DEVELOPER_DIR`

## 安装方式 B：从扩展源码重新转换

如果你想自己重新生成工程：

```bash
xcrun safari-web-extension-converter \
  replydrop-safari-distribution-0.2.264/safari-extension \
  --project-location . \
  --app-name ReplyDropSafari \
  --bundle-identifier com.replydrop.safari
```

然后用你自己的 Team ID 在 Xcode 里签名运行。

## 验证

1. 打开 `https://x.com/home`
2. 确认时间线上出现水滴评分
3. 点击工具栏 ReplyDrop 图标，确认 popup 能正常打开
4. 可选：点击页面右侧水滴入口，确认页内快速面板能展开
5. 在页面控制台执行：
   ```js
   !!window.ReplyDropAPI
   ```
   应返回 `true`

## 说明

- 公开版默认定位是“候选筛选 + 草稿辅助 + 手动发送”
- 公开源码包含页面内 API，具体怎么接入由使用者自行研究
- 是否自行扩展自动化能力，由使用者自行研究与承担风险
